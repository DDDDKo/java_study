package car;

public interface Vehicle {
	public abstract void accelerate();
	public abstract void stop();
	public abstract void setStart();
}
